from __future__ import absolute_import, division, print_function
#from msilib.schema import Class

import numpy as np
import torch
import torch.nn as nn

from collections import OrderedDict
#from layers import *

#from .resnet_encoder import ResnetEncoder
from .hr_decoder import MpvitDepthDecoder
#from .pose_decoder import PoseDecoder
from .mpvit import *


class DeepNet(nn.Module):
    def __init__(self,type,weights_init= "pretrained",num_layers=18,num_pose_frames=2,scales=range(4)):
        super(DeepNet, self).__init__()
        self.type = type
        self.num_layers=num_layers
        self.weights_init=weights_init
        self.num_pose_frames=num_pose_frames
        self.scales = scales


        if self.type =='mpvitnet':
            self.encoder = mpvit_small()
            self.decoder = MpvitDepthDecoder()
 
        else:
            print("wrong type of the networks, only depthnet and posenet")
    

    def forward(self, inputs):
        if self.type =='mpvitnet':
            self.teacher_feature = self.encoder(inputs)
            self.outputs = self.decoder(self.teacher_feature)
        else:
            self.outputs = self.decoder(self.encoder(inputs))
        return self.outputs, self.teacher_feature
