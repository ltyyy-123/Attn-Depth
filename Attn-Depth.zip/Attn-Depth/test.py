from tkinter import *
from tkinter import ttk
from tkinter import Menu, messagebox, filedialog
import os
import subprocess
import cv2
from PIL import Image, ImageTk
import threading


# ----------------------------------

class VideoPlayer:
    def __init__(self, video_source=0):
        self.video_source = video_source
        self.cap = None
        self.playing = False
        self.thread = None
        self.display_width = 700  # 显示区域宽度
        self.display_height = 500  # 显示区域高度

    def open_video(self, source):
        self.stop()
        self.video_source = source
        self.cap = cv2.VideoCapture(self.video_source)
        return self.cap.isOpened()

    def start(self, display_label):
        if self.cap is None:
            return False

        self.playing = True
        self.display_label = display_label
        self.thread = threading.Thread(target=self._update_frame)
        self.thread.daemon = True
        self.thread.start()
        return True

    def _update_frame(self):
        while self.playing and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                # 调整帧大小以适应显示区域，使用新的缩放方法
                frame = self.resize_frame_fill(frame, self.display_width, self.display_height)

                # 转换颜色从BGR到RGB
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                # 转换为PIL Image然后到ImageTk
                img = Image.fromarray(frame_rgb)
                imgtk = ImageTk.PhotoImage(image=img)

                # 在标签中显示图像
                self.display_label.config(image=imgtk)
                self.display_label.image = imgtk
            else:
                # 视频播放完毕，重新开始
                if self.video_source != 0:  # 如果不是摄像头
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                else:
                    break

    def resize_frame_fill(self, frame, target_width, target_height):
        """
        调整帧大小以填充整个目标区域，可能会裁剪部分内容
        """
        h, w = frame.shape[:2]

        # 计算宽高比
        frame_ratio = w / h
        target_ratio = target_width / target_height

        if frame_ratio > target_ratio:
            # 帧比目标区域更宽，按高度缩放
            new_h = target_height
            new_w = int(target_height * frame_ratio)
        else:
            # 帧比目标区域更高，按宽度缩放
            new_w = target_width
            new_h = int(target_width / frame_ratio)

        # 调整大小
        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)

        # 如果需要，进行居中裁剪
        if new_w > target_width or new_h > target_height:
            start_x = (new_w - target_width) // 2
            start_y = (new_h - target_height) // 2
            resized = resized[start_y:start_y + target_height, start_x:start_x + target_width]

        return resized

    def resize_frame_fit(self, frame, max_width, max_height):
        """
        调整帧大小以适应目标区域，保持宽高比，可能会有黑边
        """
        h, w = frame.shape[:2]

        # 计算缩放比例
        scale = min(max_width / w, max_height / h)

        # 计算新的尺寸
        new_w = int(w * scale)
        new_h = int(h * scale)

        # 调整大小
        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)

        # 创建黑色背景
        background = np.zeros((max_height, max_width, 3), dtype=np.uint8)

        # 将调整大小后的图像居中放置在背景上
        x_offset = (max_width - new_w) // 2
        y_offset = (max_height - new_h) // 2
        background[y_offset:y_offset + new_h, x_offset:x_offset + new_w] = resized

        return background

    def stop(self):
        self.playing = False
        if self.cap is not None:
            self.cap.release()
            self.cap = None

    def is_playing(self):
        return self.playing


# 创建视频播放器实例
video_player = VideoPlayer()


def vedioopen(i):
    if video_player.open_video(i):
        video_player.start(label6)
    else:
        messagebox.showerror("错误", f"无法打开摄像头 {i}")


def select_mp4_and_play(event):
    try:
        # 弹出文件选择对话框（只显示MP4）
        file_path = filedialog.askopenfilename(
            title="选择MP4视频文件",
            filetypes=[("MP4视频", "*.mp4"), ("所有文件", "*.*")]
        )

        if file_path:
            # 使用视频播放器播放到应用程序中
            if video_player.open_video(file_path):
                video_player.start(label6)
                print(f"正在播放: {os.path.basename(file_path)}")
            else:
                messagebox.showerror("错误", "无法打开视频文件")
        else:
            print("未选择文件")  # 用户取消选择时显示

    except Exception as e:
        print(f"错误详情：{e}")  # 控制台打印错误
        messagebox.showerror("错误", f"无法播放视频: {str(e)}")


# ----------------------------------
root = Tk()
var_cam = IntVar()
cb = ttk.Combobox(root, textvariable=var_cam, width=8)
cb["values"] = (0, 1, 2, 3)
cb['state'] = 'readonly'
cb.place_forget()


def select_camera(event):
    label1_x = label1.winfo_rootx() - root.winfo_rootx()
    label1_y = label1.winfo_rooty() - root.winfo_rooty()
    btn_x_in_label = btn_cam.winfo_x()
    btn_y_in_label = btn_cam.winfo_y()
    btn_width = btn_cam.winfo_width()
    btn_height = btn_cam.winfo_height()  # 新增

    # 放在按钮下方
    cb_x = label1_x + btn_x_in_label
    cb_y = label1_y + btn_y_in_label + btn_height + 5

    cb.place(x=cb_x, y=cb_y)
    cb.lift()


def open_selected_camera(event):
    selected_id = var_cam.get()  # 获取选择的设备编号
    vedioopen(selected_id)  # 调用函数打开摄像头


# 给下拉框绑定选择事件
cb.bind("<<ComboboxSelected>>", open_selected_camera)

# screenWidth=root.winfo_screenwidth()
# screenHeight=root.winfo_screenheight()
root.geometry("1050x800+400+100")
root.title("应用程序标题")
label1 = Label(root, text="第1步：选择视频源", width=30, height=8, anchor="nw", relief="groove", padx=10)
label1.grid(row=0, column=0, padx=10, pady=5)
label2 = Label(root, text="第2步：标记有效视窗", width=30, height=8, anchor="nw", relief="groove", padx=10)
label2.grid(row=1, column=0, padx=10, pady=5)
label3 = Label(root, text="第3步：标记视窗对应关系", width=30, height=8, anchor="nw", relief="groove", padx=10)
label3.grid(row=2, column=0, padx=10, pady=5)
label4 = Label(root, text="第4步：标记前景/背景", width=30, height=8, anchor="nw", relief="groove", padx=10)
label4.grid(row=3, column=0, padx=10, pady=5)
label5 = Label(root, text="第4步：标记前景/背景", width=30, anchor="nw", height=10, relief="groove", padx=10)
label5.grid(row=4, column=0, padx=10, pady=5)

# 增大视频显示区域的尺寸
label6 = Label(root, text="视频显示", width=85, height=35, anchor="center", relief="groove")
label6.grid(row=0, column=1, rowspan=4, sticky="nsew", pady=5, padx=5)

# 配置网格权重，使视频区域可以扩展
root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=1)
root.grid_rowconfigure(2, weight=1)
root.grid_rowconfigure(3, weight=1)
root.grid_columnconfigure(1, weight=1)


def switch_source():
    if var_video.get() == "file":
        btn_file.config(state="normal")
        btn_cam.config(state="disabled")
        btn_file.bind("<Button-1>", select_mp4_and_play)
        cb.place_forget()

    else:
        btn_cam.config(state="normal")
        btn_file.config(state="disabled")
        btn_file.unbind("<Button-1>")
        btn_cam.bind("<Button-1>", select_camera)


label7 = Label(root, text="历史记录", width=30, height=29, anchor="nw", relief="groove", padx=25)
label7.grid(row=0, rowspan=4, column=2, sticky="n", padx=10, pady=5)
label8 = Label(root, text="当前状态", width=75, height=16, anchor="nw", relief="groove", padx=20)
label8.grid(row=3, rowspan=2, column=1, columnspan=2, sticky="sw", pady=5)
var_video = StringVar()
var_video.set("file")

btn_file = Button(label1, text="选择文件...", width=10)
btn_file.place(x=100, y=28)
rb_file = Radiobutton(label1, text="视频文件", variable=var_video, value="file", command=switch_source)
rb_file.place(x=10, y=30)

btn_cam = Button(label1, text="选择设备...", width=10)
btn_cam.place(x=100, y=58)
rb_cam = Radiobutton(label1, text="摄像设备", variable=var_video, value="cam", command=switch_source)
rb_cam.place(x=10, y=60)
btn_cam.config(state="disabled")
switch_source()

var_win = StringVar(value="diameter")
rb_diameter = Radiobutton(label2, text="标记圆的两条直径", variable=var_win, value="diameter")
rb_diameter.place(x=10, y=30)
btn_mark_win1 = Button(label2, text="标记", width=7, height=3)
btn_mark_win1.place(x=150, y=29)
rb_edge = Radiobutton(label2, text="标记圆的四个边缘点", variable=var_win, value="edge")
rb_edge.place(x=10, y=60)

btn_markA = Button(label3, text="标记A点", width=8)
btn_markA.place(x=20, y=30)
btn_markB = Button(label3, text="标记B点", width=8)
btn_markB.place(x=100, y=30)
Label(label3, text="输入AB实际距离").place(x=10, y=60)
entry_ab = Entry(label3, width=5, fg="red")
entry_ab.insert(10, "2")
entry_ab.place(x=105, y=62)
Label(label3, text="米").place(x=140, y=60)

var_fg_bg = StringVar(value="fg")
rb_fg = Radiobutton(label4, text="前景", variable=var_fg_bg, value="fg")
rb_fg.place(x=10, y=30)
rb_bg = Radiobutton(label4, text="背景", variable=var_fg_bg, value="bg")
rb_bg.place(x=80, y=30)

btn_all = Button(label4, text="全是", width=6)
btn_all.place(x=10, y=65)
btn_mark_fg = Button(label4, text="标记", width=6)
btn_mark_fg.place(x=70, y=65)
btn_back = Button(label4, text="回退", width=6)
btn_back.place(x=130, y=65)
var_thresh = StringVar(value="height")
rb_height = Radiobutton(label5, text="按高度", variable=var_thresh, value="height")
rb_height.place(x=10, y=30)
entry_height = Entry(label5, width=9, fg="red")
entry_height.insert(0, "2")
entry_height.place(x=80, y=30)
Label(label5, text="米").place(x=130, y=30)

rb_area = Radiobutton(label5, text="按面积", variable=var_thresh, value="area")
rb_area.place(x=10, y=60)
entry_area = Entry(label5, width=9, fg="red")
entry_area.insert(0, "2")
entry_area.place(x=80, y=60)
Label(label5, text="米²").place(x=130, y=60)

# 按高度占比
rb_height_pct = Radiobutton(label5, text="按高度占比", variable=var_thresh, value="height_pct")
rb_height_pct.place(x=10, y=90)
entry_height_pct = Entry(label5, width=5, fg="red")
entry_height_pct.insert(0, "8")
entry_height_pct.place(x=100, y=90)
Label(label5, text="%").place(x=140, y=90)

rb_area_pct = Radiobutton(label5, text="按面积占比", variable=var_thresh, value="area_pct")
rb_area_pct.place(x=10, y=120)
entry_area_pct = Entry(label5, width=5, fg="red")
entry_area_pct.insert(0, "8")
entry_area_pct.place(x=100, y=120)
Label(label5, text="%").place(x=140, y=120)

Label(label8, text="开始时间：HH:mm:ss").place(x=54, y=20)
Label(label8, text="运行时长：HH:mm:ss").place(x=54, y=50)
Label(label8, text="预计还需 HH:mm:ss 达到处置时间。").place(x=54, y=80)

Label(label8, text="高度占比").place(x=10, y=120)
progress_height = ttk.Progressbar(label8, length=300, value=50)
progress_height.place(x=80, y=120)

Label(label8, text="面积占比").place(x=10, y=160)
progress_area = ttk.Progressbar(label8, length=300, value=50)
progress_area.place(x=80, y=160)

btn_start = Button(root, text="开始", width=15, height=8, bg="grey")
btn_start.place(x=880, y=560)


# 添加停止按钮
def stop_video():
    video_player.stop()
    # 清除显示的图像
    label6.config(image='')
    label6.config(text="视频显示")


btn_stop = Button(root, text="停止", width=15, height=2, bg="lightgrey", command=stop_video)
btn_stop.place(x=880, y=700)


# 窗口关闭时停止视频播放
def on_closing():
    video_player.stop()
    root.destroy()


root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()