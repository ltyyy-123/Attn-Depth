import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sympy as sm
from scipy.integrate import quad, dblquad
import warnings

warnings.filterwarnings('ignore')

# 配置中文字体（增强清晰度）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.size'] = 12  # 统一字体大小，提升清晰度


# -------------------------- 1. 定义物理参数与函数 --------------------------
a = 1.0  # 热扩散系数 (mm²/s)


# 初始条件：φ(ξ) = exp(-ξ²)
def phi(ξ):
    return np.exp(-ξ ** 2)


# 源项：f(ξ, τ) = 0.2
def f(ξ, τ):
    return 0.2


# -------------------------- 2. 计算解 u(x, t) --------------------------
def u(x, t):
    if t < 1e-6:
        return phi(x)

    # 第一部分：初始条件的贡献
    def integrand1(ξ):
        return phi(ξ) * np.exp(-(x - ξ) ** 2 / (4 * a ** 2 * t)) / (2 * a * np.sqrt(np.pi * t))
    integral1, _ = quad(integrand1, -10, 10, epsabs=1e-8, epsrel=1e-8)

    # 第二部分：源项的贡献
    def integrand2(ξ, τ):
        if t > τ:
            return f(ξ, τ) * np.exp(-(x - ξ) ** 2 / (4 * a ** 2 * (t - τ))) / (2 * a * np.sqrt(np.pi * (t - τ)))
        else:
            return 0
    integral2, _ = dblquad(
        integrand2,
        0, t,
        lambda τ: -10, lambda τ: 10,
        epsabs=1e-8, epsrel=1e-8
    )
    return integral1 + integral2


# -------------------------- 3. 修正的方程验证函数 --------------------------
def verify_pde(x_val, t_val):
    if abs(x_val) < 0.1:
        h = 1e-3
    else:
        h = min(1e-3, abs(x_val) * 0.01)

    if t_val < 0.1:
        h_t = 1e-3
    else:
        h_t = min(1e-3, t_val * 0.01)

    u_t = (u(x_val, t_val + h_t) - u(x_val, t_val - h_t)) / (2 * h_t)
    u_xx = (u(x_val + h, t_val) - 2 * u(x_val, t_val) + u(x_val - h, t_val)) / (h ** 2)
    residual = abs(u_t - a ** 2 * u_xx - f(x_val, t_val))
    return residual, u_t, a ** 2 * u_xx, f(x_val, t_val)


# -------------------------- 4. 物理参数验证 --------------------------
def print_physical_parameters():
    print("=" * 60)
    print("物理参数验证")
    print("=" * 60)
    print(f"热扩散系数 a = {a} mm²/s")
    print(f"  - 典型材料范围: 0.1-10 mm²/s")
    print(f"  - 当前值适合教学演示")
    print()
    print(f"初始温度分布: φ(x) = exp(-x²)")
    print(f"  - 高斯分布，峰值在x=0处")
    print()
    print(f"外部热源: f(x,t) = 0.2 W/m³")
    print(f"  - 均匀热源，模拟外部加热")
    print("=" * 60)


# -------------------------- 5. 生成网格与计算 --------------------------
def compute_solution():
    x_range = np.linspace(-1.5, 1.5, 12)
    t_range = np.linspace(0.3, 1.5, 12)
    X, T = np.meshgrid(x_range, t_range)
    U = np.zeros_like(X)

    print("开始计算数值解...")
    for i in range(len(t_range)):
        for j in range(len(x_range)):
            try:
                U[i, j] = u(X[i, j], T[i, j])
            except:
                U[i, j] = phi(X[i, j])
        if (i + 1) % 3 == 0:
            print(f"计算进度: {i + 1}/{len(t_range)} ({(i + 1) / len(t_range) * 100:.1f}%)")

    return X, T, U, x_range, t_range


# -------------------------- 6. 三维可视化（优化字体/空白） --------------------------
def create_visualization(X, T, U, x_range, t_range):
    fig = plt.figure(figsize=(10, 8))  # 缩小画布，减少空白
    ax = fig.add_subplot(111, projection='3d')

    # 绘制曲面
    surf = ax.plot_surface(
        X, T, U,
        cmap='RdYlBu_r',
        alpha=0.8,
        linewidth=0.1,
        rstride=1, cstride=1,
        antialiased=True
    )

    # 绘制离散点
    step = 2
    ax.scatter(X[::step, ::step], T[::step, ::step], U[::step, ::step],
               s=20, c='black', alpha=0.7, label='满足热传导方程的离散点')

    # 设置标签和标题（移除“修正版”）
    ax.set_xlabel('空间坐标 $x$ (mm)', fontsize=14, labelpad=8)
    ax.set_ylabel('时间 $t$ (s)', fontsize=14, labelpad=8)
    ax.set_zlabel('温度 $u(x,t)$ (°C)', fontsize=14, labelpad=8)
    ax.set_title(
        '热传导方程的三维解曲面\n$\\frac{\\partial u}{\\partial t} = a^2 \\frac{\\partial^2 u}{\\partial x^2} + f(x,t)$',
        fontsize=15, pad=15)

    # 图例和颜色条
    ax.legend(loc='upper left', fontsize=12)
    cbar = fig.colorbar(surf, ax=ax, shrink=0.7, aspect=12, label='温度 $u(x,t)$ (°C)')
    cbar.ax.tick_params(labelsize=11)

    # 视角和网格
    ax.view_init(elev=25, azim=45)
    ax.grid(True, alpha=0.3)

    # 坐标轴范围
    ax.set_xlim([x_range.min(), x_range.max()])
    ax.set_ylim([t_range.min(), t_range.max()])
    ax.set_zlim([0, max(1.0, U.max())])

    plt.tight_layout(pad=1.0)  # 减少空白
    return fig


# -------------------------- 7. 符号验证 --------------------------
def symbolic_verification():
    print("\n" + "=" * 60)
    print("符号验证：方程与解的一致性")
    print("=" * 60)

    x_sym, t_sym, xi_sym, tau_sym = sm.symbols('x t xi tau', real=True, positive=True)
    a_sym = sm.symbols('a', positive=True)
    u_sym = sm.Function('u')(x_sym, t_sym)
    phi_sym = sm.Function('phi')
    f_sym = sm.Function('f')

    eq = sm.Eq(sm.diff(u_sym, t_sym), a_sym ** 2 * sm.diff(u_sym, x_sym, 2) + f_sym(xi_sym, tau_sym))
    print("热传导方程（符号形式）：")
    sm.pprint(eq)

    u_sol_part1 = (1 / (2 * a_sym * sm.sqrt(sm.pi * t_sym))) * sm.integrate(
        phi_sym(xi_sym) * sm.exp(-(x_sym - xi_sym) ** 2 / (4 * a_sym ** 2 * t_sym)),
        (xi_sym, -sm.oo, sm.oo))

    u_sol_part2 = (1 / (2 * a_sym * sm.sqrt(sm.pi))) * sm.integrate(sm.integrate(
        f_sym(xi_sym, tau_sym) * sm.exp(-(x_sym - xi_sym) ** 2 / (4 * a_sym ** 2 * (t_sym - tau_sym))) / sm.sqrt(
            t_sym - tau_sym),
        (xi_sym, -sm.oo, sm.oo)), (tau_sym, 0, t_sym))

    u_sol = u_sol_part1 + u_sol_part2
    print("\n方程的解（符号形式）：")
    sm.pprint(u_sol)
    print("=" * 60)


# -------------------------- 8. 数值验证 --------------------------
def numerical_verification(X, T, U, x_range, t_range):
    print("\n" + "=" * 60)
    print("数值验证：离散点是否满足热传导方程")
    print("=" * 60)

    test_points = [
        (x_range[len(x_range) // 4], t_range[len(t_range) // 4]),
        (x_range[len(x_range) // 2], t_range[len(t_range) // 2]),
        (x_range[3 * len(x_range) // 4], t_range[3 * len(t_range) // 4]),
        (0.0, 1.0),
    ]

    max_residual = 0
    residuals_list = []

    for i, (x_val, t_val) in enumerate(test_points):
        try:
            residual, u_t, a2_u_xx, f_val = verify_pde(x_val, t_val)
            max_residual = max(max_residual, residual)
            residuals_list.append(residual)

            print(f"测试点 {i + 1}: (x={x_val:.2f}, t={t_val:.2f})")
            print(f"  u_t = {u_t:.6f}")
            print(f"  a²*u_xx = {a2_u_xx:.6f}")
            print(f"  f(x,t) = {f_val:.6f}")
            print(f"  残差 = {residual:.8f}")

            if residual < 1e-2:
                print("  ✅ 满足方程")
            elif residual < 1e-1:
                print("  ⚠️ 基本满足")
            else:
                print("  ❌ 不满足")
            print()
        except Exception as e:
            print(f"测试点 {i + 1}: 计算失败 - {str(e)}")
            print()

    if residuals_list:
        print(f"最大残差: {max_residual:.8f}")
        avg_residual = np.mean(residuals_list)
        print(f"平均残差: {avg_residual:.8f}")

        if max_residual < 1e-2:
            print("✅ 所有测试点都满足热传导方程！")
        elif max_residual < 1e-1:
            print("✅ 大部分测试点满足热传导方程")
        else:
            print("⚠️ 部分点残差较大，需要进一步优化")
    else:
        print("❌ 无有效验证数据")
    print("=" * 60)

    return residuals_list


# -------------------------- 9. 增强验证 --------------------------
def enhanced_verification(x_range, t_range):
    print("\n" + "=" * 60)
    print("增强验证：详细误差分析")
    print("=" * 60)

    x_test = np.linspace(-1.0, 1.0, 6)
    t_test = np.linspace(0.4, 1.2, 6)

    residuals = []
    u_t_values = []
    a2_u_xx_values = []
    f_values = []

    print("正在进行密集采样验证...")
    for i, x_val in enumerate(x_test):
        for j, t_val in enumerate(t_test):
            try:
                residual, u_t, a2_u_xx, f_val = verify_pde(x_val, t_val)
                residuals.append(residual)
                u_t_values.append(u_t)
                a2_u_xx_values.append(a2_u_xx)
                f_values.append(f_val)
            except Exception as e:
                print(f"跳过点 (x={x_val:.2f}, t={t_val:.2f}) - 计算失败")

    if len(residuals) == 0:
        print("❌ 验证失败：无有效数据点")
        return None, None, None, None

    residuals = np.array(residuals)
    u_t_values = np.array(u_t_values)
    a2_u_xx_values = np.array(a2_u_xx_values)
    f_values = np.array(f_values)

    print(f"有效采样点数: {len(residuals)}")
    print(f"平均残差: {np.mean(residuals):.8f}")
    print(f"最大残差: {np.max(residuals):.8f}")
    print(f"最小残差: {np.min(residuals):.8f}")
    print(f"标准差: {np.std(residuals):.8f}")

    good_points = np.sum(residuals < 1e-2)
    fair_points = np.sum((residuals >= 1e-2) & (residuals < 1e-1))
    poor_points = np.sum(residuals >= 1e-1)

    print(f"\n误差分布:")
    print(f"  - 高精度 (<0.01): {good_points}点 ({good_points / len(residuals) * 100:.1f}%)")
    print(f"  - 中等精度 (0.01-0.1): {fair_points}点 ({fair_points / len(residuals) * 100:.1f}%)")
    print(f"  - 低精度 (>0.1): {poor_points}点 ({poor_points / len(residuals) * 100:.1f}%)")

    if len(u_t_values) > 1:
        correlation = np.corrcoef(u_t_values, a2_u_xx_values + f_values)[0, 1]
        print(f"\nu_t 与 (a²*u_xx + f) 的相关系数: {correlation:.6f}")

        if correlation > 0.9:
            print("✅ 优秀：高度相关，方程满足性很好")
        elif correlation > 0.7:
            print("✅ 良好：相关性较好，方程基本满足")
        elif correlation > 0.5:
            print("⚠️ 一般：相关性中等，需要改进")
        else:
            print("❌ 较差：相关性较低，需要重新检查")

    return residuals, u_t_values, a2_u_xx_values, f_values


# -------------------------- 10. 统计信息 --------------------------
def print_statistics(U, x_range, t_range):
    print("\n" + "=" * 60)
    print("计算统计信息")
    print("=" * 60)
    print(f"网格大小: {len(t_range)} × {len(x_range)} = {len(t_range) * len(x_range)} 个点")
    print(f"空间范围: [{x_range.min():.1f}, {x_range.max():.1f}] mm")
    print(f"时间范围: [{t_range.min():.1f}, {t_range.max():.1f}] s")
    print(f"温度范围: {U.min():.6f} ~ {U.max():.6f} °C")
    print(f"平均温度: {U.mean():.6f} °C")
    print(f"总热量（近似）: {np.trapz(np.trapz(U, x_range), t_range):.2f} °C·mm·s")
    print("=" * 60)


# -------------------------- 11. 创建分析图表（优化字体/空白） --------------------------
def create_analysis_plots(X, T, U, x_range, t_range, residuals=None):
    if residuals is None:
        print("跳过分析图表生成（验证数据不足）")
        return

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))  # 缩小画布，减少空白
    fig.suptitle('', fontsize=16)  # 移除顶部标题，减少空白

    # 1. 不同时刻的温度分布
    ax1 = axes[0, 0]
    time_indices = [0, len(t_range) // 4, len(t_range) // 2, -1]
    colors = ['blue', 'green', 'orange', 'red']
    for idx, color in zip(time_indices, colors):
        ax1.plot(x_range, U[idx, :], color=color, linewidth=2,
                 label=f't={t_range[idx]:.2f}s')
    ax1.set_xlabel('空间位置 x (mm)', fontsize=13)
    ax1.set_ylabel('温度 u(x,t) (°C)', fontsize=13)
    ax1.set_title('不同时刻的温度分布', fontsize=14)
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3)

    # 2. 中心点温度随时间变化
    ax2 = axes[0, 1]
    center_idx = np.argmin(np.abs(x_range))
    ax2.plot(t_range, U[:, center_idx], 'r-', linewidth=2, marker='o', markersize=4)
    ax2.set_xlabel('时间 t (s)', fontsize=13)
    ax2.set_ylabel('中心点温度 (°C)', fontsize=13)
    ax2.set_title('中心点温度随时间变化', fontsize=14)
    ax2.grid(True, alpha=0.3)

    # 3. 残差分布直方图
    ax3 = axes[1, 0]
    ax3.hist(residuals, bins=min(10, len(residuals)), alpha=0.7, color='skyblue', edgecolor='black')
    ax3.set_xlabel('残差值', fontsize=13)
    ax3.set_ylabel('频次', fontsize=13)
    ax3.set_title('残差分布直方图', fontsize=14)
    ax3.grid(True, alpha=0.3)
    ax3.axvline(np.mean(residuals), color='red', linestyle='--',
                label=f'均值: {np.mean(residuals):.6f}')
    ax3.legend(fontsize=11)

    # 4. 温度梯度分布
    ax4 = axes[1, 1]
    gradient = np.gradient(U, axis=1)
    im = ax4.imshow(gradient, aspect='auto', cmap='seismic',
                    extent=[x_range.min(), x_range.max(), t_range.max(), t_range.min()])
    ax4.set_xlabel('空间位置 x (mm)', fontsize=13)
    ax4.set_ylabel('时间 t (s)', fontsize=13)
    ax4.set_title('温度梯度分布', fontsize=14)
    plt.colorbar(im, ax=ax4, label='∂u/∂x')

    plt.tight_layout(pad=1.0)  # 减少空白
    plt.savefig('heat_equation_analysis.png', dpi=300, bbox_inches='tight')  # 移除“fixed”后缀
    print("✅ 分析图表已保存为 'heat_equation_analysis.png'")
    plt.show()


# -------------------------- 12. 主函数 --------------------------
def main():
    print("热传导方程数值求解与可视化")
    print("基于参考论文《Python在《数学物理方程》教学中的应用研究》")
    print("作者：热合买提江·依明")

    print_physical_parameters()
    X, T, U, x_range, t_range = compute_solution()
    fig = create_visualization(X, T, U, x_range, t_range)
    plt.savefig('heat_equation_3d_solution.png', dpi=300, bbox_inches='tight')  # 移除“fixed”后缀
    print("\n✅ 三维图像已保存为 'heat_equation_3d_solution.png'")
    plt.show()

    symbolic_verification()
    residuals_list = numerical_verification(X, T, U, x_range, t_range)
    residuals, u_t_values, a2_u_xx_values, f_values = enhanced_verification(x_range, t_range)
    print_statistics(U, x_range, t_range)
    create_analysis_plots(X, T, U, x_range, t_range, residuals)

    print("\n🎉 分析完成！")
    print("生成的文件:")
    print("  - heat_equation_3d_solution.png (三维解曲面)")
    print("  - heat_equation_analysis.png (分析图表)")


if __name__ == "__main__":
    main()